#include <iostream>

using namespace std;

#include "templates.h"
#include "aghFib.h"