#ifndef AGHFIB_H
#define	AGHFIB_H

class aghFib {
public:
	int operator[](int);
private:
};

#endif	/* AGHFIB_H */

